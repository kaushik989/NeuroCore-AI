import time
import torch
from models.lstm_model import BurnoutLSTM

model = BurnoutLSTM(10, 64, 2)
model.eval()

dummy_input = torch.randn(1, 50, 10)

start = time.time()
for _ in range(1000):
    model(dummy_input)
end = time.time()

print("Average Inference Time:", (end - start) / 1000)
