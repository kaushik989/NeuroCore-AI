import torch
import torch.nn as nn

class BurnoutLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers):
        super(BurnoutLSTM, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        out, _ = self.lstm(x)
        out = out[:, -1, :]
        out = self.fc(out)
        return self.sigmoid(out)
