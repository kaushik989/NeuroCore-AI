# Performance Benchmark

| Mode | Avg Latency | Throughput | Notes |
|------|------------|------------|-------|
| CPU Only | XX ms | XX req/s | Baseline |
| ROCm GPU | XX ms | XX req/s | 30% faster |
